#include <preinscripcion.h>
#include <funciones.h>
#include <list>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
using ::testing::StartsWith;

TEST(Preinscripcion, Cambiar_estado){
	std::list <Preinscripcion> pre_list;
	Preinscripcion p1(1, 1, "User1", false, true);
	Preinscripcion p2(2, 2, "User2", false, false);
	AddListPre(p1,pre_list);
	AddListPre(p2,pre_list);
	EXPECT_EQ(true, ChangeStatus(p1.GetPreId(), pre_list));
	EXPECT_EQ(false, ChangeStatus(p2.GetPreId(), pre_list));
}

TEST(Preinscripcion, Añadir_preinscripción){
	std::list <Preinscripcion> pre_list;
	Preinscripcion p(1, 1);
	EXPECT_EQ(true, AddListPre(p,pre_list));
	Preinscripcion e(1, 2);
	EXPECT_EQ(false, AddListPre(e,pre_list));
}

int main(int argc, char** argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}