#include <funciones.h>
#include <actividad.h>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
using ::testing::StartsWith;

TEST(Actividad, CheckStringN) {
    std::string cad1="hola";
    std::string cad2="1";
    std::string cad3="hola mundo";
    std::string cad4="123hola";
    std::string cad5="";
    int aux;
    EXPECT_EQ(false, CheckStringN(cad1, aux));
    EXPECT_EQ(true, CheckStringN(cad2, aux));
    EXPECT_EQ(false, CheckStringN(cad3, aux));
    EXPECT_EQ(false, CheckStringN(cad4, aux));
    EXPECT_EQ(false, CheckStringN(cad5, aux));

}

TEST(Actividad, TurnInt) {
    std::string cad1="2045";
    std::string cad2="1";

    EXPECT_EQ(2045, TurnInt(cad1));
    EXPECT_EQ(1, TurnInt(cad2));
}

int main(int argc, char** argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}