#include <actividad.h>
#include <funciones.h>
#include <list>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
using ::testing::StartsWith;

TEST(Actividad, AddList) {
  Actividad a1(10);
  Actividad a2(11);
  std::list <Actividad> act_list;
  AddList(a1, act_list);
  EXPECT_EQ(true, FindList(a1.GetActId(), act_list));
  EXPECT_EQ(false, FindList(a2.GetActId(), act_list));
}


TEST(Actividad, DeleteList) {
    Actividad a1(10);
    Actividad a2(11);
    std::list <Actividad> act_list;
    act_list.push_back(a1);
    act_list.push_back(a2);
    DeleteList(a1, act_list);
    EXPECT_EQ(false, FindList(a1.GetActId(), act_list));
    EXPECT_EQ(true, FindList(a2.GetActId(), act_list));

}

int main(int argc, char** argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}