#include <inscripcion.h>
#include <funciones.h>
#include <list>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
using ::testing::StartsWith;

TEST(Inscripcion, Añadir_inscripción){
	std::list <Inscripcion> ins_list;
	Inscripcion i(1, 1);
	EXPECT_EQ(true, AddListIns(i,ins_list));
	Inscripcion a(1, 2);
	EXPECT_EQ(false, AddListIns(a,ins_list));
}

TEST(Inscripcion, Borrar_inscripción){
	std::list <Inscripcion> ins_list;
	Inscripcion i(1, 1);
	AddListIns(i,ins_list);
	EXPECT_EQ(true, DeleteListIns(i,ins_list));
	Inscripcion a(1, 2);
	EXPECT_EQ(false, DeleteListIns(a,ins_list));
}

int main(int argc, char** argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}