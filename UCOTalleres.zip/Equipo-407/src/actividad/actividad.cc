#include "actividad.h"
#include "funciones.h"
#include <list>

Actividad::Actividad(int act_id,std::string name, std::string begin_date, std::string end_date, bool status,std::string description,float price,int capacity,int faculty_id)
{
    act_id_=act_id;
    name_=name;
    begin_date_=begin_date;
    end_date_=end_date;
    status_=status;
    description_=description;
    price_=price;
    capacity_=capacity;
    faculty_id_=faculty_id;
}

void CreateAct(int act_count,std::list <Actividad> &act_list)
{
    Actividad a(act_count);
    AddInfo(a);
    AddList(a, act_list);
}

void ChangeAct(Actividad &a)
{
    int id=a.GetActId();
    std::cout<<"-----------------------------------------------------------------------\n";
    std::cout<<"Seleccione el campo a modificar:"<<std::endl;
    std::cout<<"1)Nombre"<<std::endl;
    std::cout<<"2)Fecha de inicio"<<std::endl;
    std::cout<<"3)Fecha de finalización"<<std::endl;
    std::cout<<"4)Descripción"<<std::endl;
    std::cout<<"5)Precio"<<std::endl;
    std::cout<<"6)Aforo"<<std::endl;
    std::cout<<"7)ID de la facultad"<<std::endl;
    std::cout<<"-----------------------------------------------------------------------\n"<<std::endl;
    std::cout<<"--> ";
    int i;
    std::cin>>i;
    std::cout<<std::endl;
    std::cin.ignore();
    std::string n, aux;
    int m;
	float j;
    switch(i) //NO SE PUEDEN DECLARAR VARIAS VARIABLES CON EL MISMO NOMBRE Y DISTINTO TIPO, DECLARAR TODAS ANTES DE EMPEZAR EL SWITCH
    { //DECLARAR i ANTES DE ELEGIR EL SWITCH Y HACER cin
        case 1:
            std::cout<<"Introduzca el nuevo campo para la actividad: ";
            
            std::cin.ignore();
            getline(std::cin, n);
            a.SetName(n);
            std::cout<<"\n~Actividad modificada correctamente~\n";
        break;

        case 2:
            std::cout<<"Introduzca el nuevo campo para la actividad (DD/MM/AA): ";
            getline(std::cin, aux);
            if(CheckDate(aux, n)==true)
            {
                if(CheckBothDates(n, a.GetEndDate())==true)
                {
                    a.SetBeginDate(n);
                    std::cout<<"\n~Actividad modificada correctamente~\n";
                }
                else
                {
                    std::cout<<"\n~La fecha de inicio no puede ser posterior a la de finalizacion. No se ha guardado el cambio.~\n";
                }
            }
            else
            {
                std::cout<<"\n~Valor no valido. No se ha guardado el cambio~\n";
            }
        break;

        case 3:
            std::cout<<"Introduzca el nuevo campo para la actividad (DD/MM/AA): ";
            getline(std::cin, aux);
            if(CheckDate(aux, n)==true)
            {
                if(CheckBothDates(a.GetBeginDate(), n)==true)
                {
                    a.SetBeginDate(n);
                    std::cout<<"\n~Actividad modificada correctamente~\n";
                }
                else
                {
                    std::cout<<"\n~La fecha de inicio no puede ser posterior a la de finalizacion. No se ha guardado el cambio~\n";
                }
            }
            else
            {
                std::cout<<"\n~Valor no valido. No se ha guardado el cambio~\n";
            }
        break;

        case 4:
            std::cout<<"Introduzca el nuevo campo para la actividad: ";
            getline(std::cin, n);
            a.SetDescription(n);
            std::cout<<"\n~Actividad modificada correctamente~\n";
        break;

		case 5:
            std::cout<<"Introduzca el nuevo campo para la actividad: ";
            getline(std::cin, aux);
            CheckFloat(aux, j);
            if(j!=-10000)
            {
                a.SetPrice(j);
                std::cout<<"\n~Actividad modificada correctamente~\n";
            }
            else
            {
                std::cout<<"\n~Valor no valido. No se ha guardado el cambio~\n";
            }
        break;

        case 6://CAMBIAR m POR EJEMPLO
            std::cout<<"Introduzca el nuevo campo para la actividad: ";
            getline(std::cin, aux);
            CheckStringN(aux, m);
            if(m!=-10000)
            {
                a.SetCapacity(m);
                std::cout<<"\n~Actividad modificada correctamente~\n";
            }
            else
            {
                std::cout<<"\n~Valor no valido. No se ha guardado el cambio~\n";
            }
        break;

        case 7: //CAMBIAR A m POR EJEMPLO
            std::cout<<"Introduzca el nuevo campo para la actividad: ";
            getline(std::cin, aux);
            CheckStringN(aux, m);
            if(m!=-10000)
            {
                a.SetFacultyId(m);
                std::cout<<"\n~Actividad modificada correctamente~\n";
            }
            else
            {
                std::cout<<"\n~Valor no valido. No se ha guardado el cambio~\n";
            }
        break;

        default:
            std::cout<<"~Opcion no valida~\n"<<std::endl;
        break;
    }
}

void AddInfo(Actividad &a)
{

    std::string name ,description ,begin_date ,end_date, aux;
	int capacity=-1,faculty_id=-1;
	float price=-1;
    std::cout<<"Introduzca el nombre de la actividad: ";
    std::cin.ignore();
    getline(std::cin, name);
    do
    {
        std::cout<<"Introduzca la fecha de inicio de la actividad (DD/MM/AA): ";
        do
        {
            getline(std::cin, aux);
            CheckDate(aux, begin_date);
            if(begin_date!="-10000")
            {
                a.SetBeginDate(begin_date);
            }
            else
            {
                std::cout<<"~Formato de fecha incorrecto. Introduzca la fecha de nuevo: ";
            }
        }while(begin_date=="-10000");
        std::cout<<"Introduzca la fecha de finalización de la actividad (DD/MM/AA): ";
        do
        {
            getline(std::cin, aux);
            CheckDate(aux, end_date);
            if(end_date!="-10000")
            {
                a.SetEndDate(end_date);
            }
            else
            {
                std::cout<<"~Formato de fecha incorrecto. Introduzca la fecha de nuevo: ";
            }
        }while(end_date=="-10000");
        if(CheckBothDates(a.GetBeginDate(), a.GetEndDate())==false)
        {
            std::cout<<"~La fecha de inicio no puede ser posterior a la de finalizacion. Vuelva a introducir las fechas~\n";
        }
    }while (CheckBothDates(a.GetBeginDate(), a.GetEndDate())==false);
    std::cout<<"Introduzca el aforo de la actividad: ";
    //std::cin.ignore();
    while(capacity<=0)
    {
        getline(std::cin, aux);
        CheckStringN(aux, capacity);
        if(capacity!=-10000)
        {
            a.SetCapacity(capacity);
        }
        else
        {
            std::cout<<"Valor no valido. Introduzca un nuevo valor: ";
        }
    }
	std::cout<<"Introduzca el precio de inscripción a la actividad: ";
    while(price<0)
    {
        getline(std::cin, aux);
        CheckFloat(aux, price);
        if(price!=-10000)
        {
            a.SetPrice(price);
        }
        else
        {
            std::cout<<"~Valor no valido. Introduzca un nuevo valor: ";
        }
    }
    std::cout<<"Introduzca el id de la facultad a la que se asocia la actividad: ";
    while(faculty_id<0)
    {
        getline(std::cin, aux);
        CheckStringN(aux, faculty_id);
        if(faculty_id!=-10000)
        {
            a.SetFacultyId(faculty_id);
        }
        else
        {
            std::cout<<"~Valor no valido. Introduzca un nuevo valor: ";
        }
    }
    std::cout<<"Introduzca la descripción de la actividad: ";
    getline(std::cin, description);
    a.SetName(name);
	a.SetStatus(false);
	a.SetDescription(description);
}

void ShowAct(Actividad &a)
{
    a.SetStatus(true);
}

void HideAct(Actividad &a)
{
    a.SetStatus(false);
}

void SeeActs(int rol, std::list<Actividad> act_list)
{
    int cont=0;
    if(rol==1 || rol==2)
    {   
        for(auto it=act_list.begin();it!=act_list.end();++it)
        {
            if(it->GetStatus()==true) //Poner con formato
            {
                cont++;
                std::cout<<"ID:                         "<<it->GetActId()<<std::endl;
                std::cout<<"Nombre:                     "<<it->GetName()<<std::endl;
                std::cout<<"Fecha de Inicio:            "<<it->GetBeginDate()<<std::endl;
                std::cout<<"Fecha de Finalizacion:      "<<it->GetEndDate()<<std::endl;
                std::cout<<"Aforo:                      "<<it->GetCapacity()<<std::endl;
                std::cout<<"Precio:                     "<<it->GetPrice()<<std::endl;
                std::cout<<"ID de la facultad asociada: "<<it->GetFacultyId()<<std::endl;
                std::cout<<it->GetDescription()<<std::endl;
                std::cout<<std::endl;
            }
        }
        if(cont==0)
        {
            std::cout<<"~No hay actividades activas en este momento~"<<std::endl;
        }
    }
    else
    {
        if(act_list.size()==0)
        {
            std::cout<<"~No existe ninguna actividad~"<<std::endl;
        }
        else
        {
            for(auto it=act_list.begin();it!=act_list.end();++it)
            {
                cont++;
                std::cout<<"ID:                         "<<it->GetActId()<<std::endl;
                std::cout<<"Nombre:                     "<<it->GetName()<<std::endl;
                std::cout<<"Fecha de Inicio:            "<<it->GetBeginDate()<<std::endl;
                std::cout<<"Fecha de Finalizacion:      "<<it->GetEndDate()<<std::endl;
                std::cout<<"Aforo:                      "<<it->GetCapacity()<<std::endl;
                std::cout<<"Precio:                     "<<it->GetPrice()<<std::endl;
                std::cout<<"ID de la facultad asociada: "<<it->GetFacultyId()<<std::endl;
                if(it->GetStatus()==1)
                {
                    std::cout<<"Estado:                     ACTIVA"<<std::endl;
                }
                else
                {
                    std::cout<<"Estado:                     INACTIVA"<<std::endl;
                }
                std::cout<<it->GetDescription()<<std::endl;
                std::cout<<std::endl;
            }
        }
    }
}

bool AddList(Actividad a,std::list <Actividad> &act_list)
{
	for(auto it=act_list.begin(); it!=act_list.end(); ++it)
    {
		if(it->GetActId()==a.GetActId())
        {
			return false;
		}
	}
	act_list.push_back(a);
	return true;
}

bool DeleteList(Actividad a,std::list <Actividad> &act_list)
{
	for(auto it=act_list.begin(); it!=act_list.end(); ++it){
		if(it->GetActId()==a.GetActId()){
			act_list.erase(it);
			return true;
		}
	}
	return false;
}

bool FindList(int act_id, std::list <Actividad> act_list)
{
    for(auto it=act_list.begin(); it!=act_list.end(); it++)
    {
        if(act_id==it->GetActId())
        {
            return true;
        }
    }
    return false;
}

bool CheckString1(std::string aux, int &num)
{
    if(isdigit(aux[0])==0)
    {
        num=20;
        return false;
    }
    num=TurnInt(aux);
    return true;
}

bool CheckStringN(std::string aux, int &num)
{
    if(aux.size()==0)
    {
        num=-10000;
        return false;
    }
    for(int i=0; i<aux.size(); i++)
    {
        if(isdigit(aux[i])==0)
        {
            num=-10000;
            return false;
        }
    }
    num=TurnInt(aux);
    return true;
}

int TurnInt(std::string aux)
{
    int aux2;
    aux2=stoi(aux);
    return aux2;
}

//FUNCION NUEVA
bool CheckFloat(std::string aux, float &num)
{
    if(isdigit(aux[0])==0)
    {
        num=-10000;
        return false;
    }
    if(isdigit(aux[aux.size()-1])==0)
    {
        num=-10000;
        return false;  
    }
    for(int i=0; i<aux.size(); i++)
    {
        if(isdigit(aux[i])==0 && aux[i]!=',' && aux[i]!='.')
        {
            num=-10000;
            return false;
        }
        if(aux[i]==',')
        {
            aux[i]='.';
        }
    }
    num=stof(aux);
    return true;
}

bool CheckDate(std::string aux, std::string &cad)
{
    int dia, mes, anio;
    if(aux.size()!=8)
    {
        cad="-10000";
        return false;
    }
    if(isdigit(aux[0])==0 || isdigit(aux[1])==0 || isdigit(aux[3])==0 || isdigit(aux[4])==0 || isdigit(aux[6])==0 || isdigit(aux[7])==0)
    {
        cad="-10000";
        return false;
    }
    if(aux[2]!='/' || aux[5]!='/')
    {
        cad="-10000";
        return false;
    }
    dia=(aux[0]-'0')*10 + (aux[1]-'0');
    mes=(aux[3]-'0')*10 + (aux[4]-'0');
    anio=(aux[6]-'0')*10 + (aux[7]-'0');
    if(dia<1 || dia>31 || mes<1 || mes>12 || anio<00 || (dia==30 && mes==2) || (dia==31 && (mes==2 || mes==4 || mes==6 || mes==9 || mes==11)))
    {
        cad="-10000";
        return false;
    }
    cad=aux;

    return true;
}

bool CheckBothDates(std::string begin, std::string end)
{
    int dia1, mes1, anio1, dia2, mes2, anio2;
    dia1=(begin[0]-'0')*10 + (begin[1]-'0');
    mes1=(begin[3]-'0')*10 + (begin[4]-'0');
    anio1=(begin[6]-'0')*10 + (begin[7]-'0');
    dia2=(end[0]-'0')*10 + (end[1]-'0');
    mes2=(end[3]-'0')*10 + (end[4]-'0');
    anio2=(end[6]-'0')*10 + (end[7]-'0');
    if(anio1>anio2 || (anio1<=anio2 && mes1>mes2) || (anio1<=anio2 && mes1<=mes2 && dia1>dia2))
    {
        return false;
    }
    return true;
}


//FUNCION NUEVA
int CountCapacity(std::list <Inscripcion> &ins_list, std::list <Preinscripcion> &pre_list, Actividad &a)
{
    int cont=0;
    for(auto it=ins_list.begin(); it!=ins_list.end(); it++)
    {
        if(a.GetActId()==it->GetActId())
        {
            cont++;
        }
    }
    for(auto it=pre_list.begin(); it!=pre_list.end(); it++)
    {
        if(a.GetActId()==it->GetActId())
        {
            cont++;
        }
    }
    return cont;
}